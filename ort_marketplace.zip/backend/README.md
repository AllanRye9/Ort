# VideoDownloader v2 — FastAPI Backend

Real-time video downloader API built with **FastAPI** + **Socket.IO** + **yt-dlp**.
Connects to the Flutter frontend via REST + Socket.IO.

---

## Quick start

### 1. Prerequisites
- Python 3.11+
- `ffmpeg` in `PATH` (required by yt-dlp to merge video+audio streams)
  ```bash
  # macOS
  brew install ffmpeg
  # Ubuntu/Debian
  sudo apt install ffmpeg
  # Windows
  winget install ffmpeg
  ```

### 2. Install dependencies
```bash
cd backend
pip install -r requirements.txt
```

### 3. Run
```bash
# Development (auto-reload)
uvicorn main:socket_app --host 0.0.0.0 --port 8000 --reload

# Production
uvicorn main:socket_app --host 0.0.0.0 --port 8000 --workers 1
```

> **Note:** Use `--workers 1`. Socket.IO's in-process job store is not
> shared across worker processes. For multi-worker deployments, replace
> the `jobs` dict with Redis and configure `python-socketio` with a
> Redis message queue adapter.

### 4. Open the Swagger UI
Visit **http://localhost:8000/docs** — all endpoints are fully documented
and can be tested directly from the browser.

---

## Environment variables

| Variable | Default | Description |
|---|---|---|
| `DOWNLOADS_DIR` | `downloads/` | Directory where yt-dlp saves files |
| `MAX_CONCURRENT_DOWNLOADS` | `3` | Max parallel downloads |
| `PORT` | `8000` | Port (used by `python main.py`) |

---

## API reference

| Method | Path | Body / Params | Response |
|---|---|---|---|
| `GET` | `/` | — | `{status, version, jobs}` |
| `POST` | `/start_download` | form: `url`, `format`, `cookies?` | `{download_id}` |
| `GET` | `/status/{id}` | — | `{url, title, status, percent, error}` |
| `GET` | `/files` | — | `[{name, size, modified, path}]` |
| `GET` | `/downloads/{filename}` | — | File stream |
| `DELETE` | `/files/{filename}` | — | `{deleted}` |

### Socket.IO events

**Server → Client**

| Event | Payload | Meaning |
|---|---|---|
| `progress` | `{id, line}` | yt-dlp download progress line |
| `completed` | `{id}` | Download finished successfully |
| `failed` | `{id, error}` | Download failed |
| `files_updated` | `{}` | File list changed — re-fetch `/files` |

**Client → Server**

| Event | Payload | Meaning |
|---|---|---|
| `subscribe` | `{download_id}` | Join the room for a job (call after `start_download`) |

---

## Deployment on Render (free tier)

1. Push `backend/` to a GitHub repo.
2. New **Web Service** → set **Start Command**:
   ```
   uvicorn main:socket_app --host 0.0.0.0 --port $PORT
   ```
3. Add env var `DOWNLOADS_DIR=/tmp/downloads` (ephemeral — files reset on redeploy).
4. Set the Flutter app's server URL to `https://your-app.onrender.com`.

---

## Common errors & fixes

| Error | Fix |
|---|---|
| `ERROR: Postprocessing: ffprobe and ffmpeg not found` | Install `ffmpeg` and ensure it is in PATH |
| `Socket.IO connection refused` | Make sure you're running `main:socket_app`, not `main:app` |
| `422 Unprocessable Entity` on `/start_download` | The request must use `Content-Type: application/x-www-form-urlencoded`, not JSON |
| `403 Access denied` on `/downloads/` | Filename contains `..` — path traversal blocked |
